/* WD1-L4: Student grades using arrays and a for loop */

// Arrays as containers (same index = same student)
var studentNames  = ["Anna Reyes", "Ben Santos", "Carla Cruz", "David Lim", "Ella Ramos"];
var studentGrades = [92, 85, 78, 97, 74];

// Returns the grade equivalent for a numeric grade
function getEquivalent(grade) {
  if (grade >= 95) return "1.0";
  if (grade >= 90) return "1.5";
  if (grade >= 85) return "2.0";
  if (grade >= 80) return "2.5";
  if (grade >= 78) return "2.75";
  if (grade >= 75) return "3.0";
  return "Failed";
}

// Returns "Passed" or "Failed" (passing grade is 75)
function getRemark(grade) {
  return grade >= 75 ? "Passed" : "Failed";
}

// Returns the academic leader title, or "-" if none
function getAcademicLeader(grade) {
  if (grade >= 95) return "1st Class Academic Leader";
  if (grade >= 90) return "2nd Class Academic Leader";
  return "-";
}

// Builds the "List of Enrolled Students" table
function showStudents() {
  var body = document.querySelector("#studentTable tbody");
  var rows = "";

  for (var i = 0; i < studentNames.length; i++) {
    rows += "<tr><td>" + studentNames[i] + "</td><td>" + studentGrades[i] + "</td></tr>";
  }
  body.innerHTML = rows;
}

// Builds the "Grade Equivalents" table using one loop for all students
function showGradeEquivalents() {
  var body = document.querySelector("#equivalentTable tbody");
  var rows = "";

  for (var i = 0; i < studentNames.length; i++) {
    var grade = studentGrades[i];
    rows += "<tr>" +
      "<td>" + studentNames[i] + "</td>" +
      "<td>" + grade + "</td>" +
      "<td>" + getEquivalent(grade) + "</td>" +
      "<td>" + getRemark(grade) + "</td>" +
      "<td>" + getAcademicLeader(grade) + "</td>" +
      "</tr>";
  }
  body.innerHTML = rows;
  document.getElementById("equivalents").hidden = false;
}

// Run on page load and wire up the button
showStudents();
document.getElementById("showBtn").addEventListener("click", showGradeEquivalents);